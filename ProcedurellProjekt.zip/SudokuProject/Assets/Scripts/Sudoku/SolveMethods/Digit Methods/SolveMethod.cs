﻿public abstract class SolveMethod
{
    public abstract string GetName { get; }
    public abstract PuzzleDifficulty Difficulty { get; }
}